/****************************************************************
Main CPP for Rollman wheel encoder.

21 Dec 2015- Amy, SunFounder Electronics

Code developed in Arduino 1.6.5.
****************************************************************/

#include "Rollman.h"

RollmanKalman::RollmanKalman() {
    Q_angle = 0.001f;
    Q_bias = 0.003f;
    R_measure = 0.03f;

    angle = 0.0f; // Reset the angle-重置角度值
    bias = 0.0f; // Reset bias-重置偏差值

    P[0][0] = 0.0f; // 假设偏差为0，角度为0，矩阵如下：
    P[0][1] = 0.0f;
    P[1][0] = 0.0f;
    P[1][1] = 0.0f;
};

float RollmanKalman::getAngle(float newAngle, float newRate, float dt) {
    /* Step 1-计算角度：新的位置-平衡的偏差量 */
    rate =newRate - bias ;
    angle += dt * rate ;

    /* Step 2-更新估计误差协方差 */
    P[0][0] += dt * (dt*P[1][1] - P[0][1] - P[1][0] + Q_angle);
    P[0][1] -= dt * P[1][1];
    P[1][0] -= dt * P[1][1];
    P[1][1] += Q_bias * dt;

    /* Step 3-测量更新，计算卡尔曼增益 */
    float S = P[0][0] + R_measure; // Estimate error-估计误差
	
    /* Step 4-增益-2元矢量*/
    float K[2];
    K[0] = P[0][0] / S;
    K[1] = P[1][0] / S;
	
    /* Step 5-计算角度偏差*/
    float angle_err = newAngle - angle; 
	
    /* Step 6-角度和偏差 */
    angle += K[0] * angle_err;
    bias += K[1] * angle_err;

    /* Step 7-计算矩阵的新值*/
    float P00_temp = P[0][0];
    float P01_temp = P[0][1];

    P[0][0] -= K[0] * P00_temp;
    P[0][1] -= K[0] * P01_temp;
    P[1][0] -= K[1] * P00_temp;
    P[1][1] -= K[1] * P01_temp;

    return angle;
};

void RollmanKalman::setAngle(float angle) { this->angle = angle; }; // Used to set angle, this should be set as the starting angle-设置初始角度
void RollmanKalman::setQangle(float Q_angle) { this->Q_angle = Q_angle; };
void RollmanKalman::setQbias(float Q_bias) { this->Q_bias = Q_bias; };
void RollmanKalman::setRmeasure(float R_measure) { this->R_measure = R_measure; };

float RollmanKalman::getRate() { return this->rate; }; // Return the unbiased rate-返回无偏率
float RollmanKalman::getQangle() { return this->Q_angle; };
float RollmanKalman::getQbias() { return this->Q_bias; };
float RollmanKalman::getRmeasure() { return this->R_measure; };
