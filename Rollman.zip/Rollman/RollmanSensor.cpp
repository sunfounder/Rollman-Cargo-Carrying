/****************************************************************
Main CPP for Rollman IR reflectance sensors.

21 Dec 2015- Amy, SunFounder Electronics

Code developed in Arduino 1.6.5.
****************************************************************/

#include "Rollman.h"
#include <Arduino.h>

RollmanSensor::RollmanSensor(int pin)
{
  _pin = pin;
  _BGLevel = -1;     //背影亮度
  _detectLevel = -1; //检测胶带亮度
}

int RollmanSensor::read()//读
{
  return analogRead(_pin);
}

// If the background and detection levels for this sensor have beenset, returns true.
// 背景和灵敏度已经调整合适，返回真。
boolean RollmanSensor::calStatus()
{
  if (_BGLevel != -1 && _detectLevel != -1) return true;
  else                                      return false;
}

// An attempt at a decent single-call, quick return line detection function.
boolean RollmanSensor::check()
{
  // Collect a sample.//收集样品，红外传感器现在检测到的值
  int level = analogRead(_pin);
  
  // 与环境进行比较；地面越黑，电压越高。
  // Remember, the darker the surface, the higher the value returned.
  if (_BGLevel < _detectLevel) // Light-on-dark situation//在黑暗的环境中
  {
    // For a light-on-dark detection, we're looking to see if the level is
    //  higher than _BGLevel. Our threshold will be a rise above the BGLevel
    //  of 1/4 the difference between background and detect levels.
	//如果在比较黑的环境中，或值将提高四分之一
    int threshold = (_detectLevel - _BGLevel)>>2;//差值=1/4（检测值-环境值）
    if (level-threshold > _BGLevel) return true; //传感器检测值-差值>环境值
    else                            return false;
  }
  else // Dark-on-light situation//在比较亮的环境中
  {
    // For a dark-on-light detection, we'll do exactly the opposite: check to
    //  see if the level is lower than _BGLevel by at least 1/4 the difference
    //  between the levels.
    int threshold = (_BGLevel - _detectLevel)>>2;//差值=1/4（环境值-检测值）
    if (level+threshold < _BGLevel) return true; //传感器检测值+差值>环境值
    else                            return false;
  }
}

// setBGLevel() is used to calibrate the level that we expect to see when we
//  aren't seeing something interesting. 
int RollmanSensor::setBGLevel()//环境值
{
  _BGLevel = analogRead(_pin); 

  return _BGLevel;
}

// setDetectLevel() works exactly the same as setBGLevel(), but with different
//  variables. 
int RollmanSensor::setDetectLevel()//检测值
{
  _detectLevel = analogRead(_pin);

  return _detectLevel;
}