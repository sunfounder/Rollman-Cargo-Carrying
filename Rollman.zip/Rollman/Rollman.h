/****************************************************************
Core header file for all the various Rollman functions.

21 Dec 2015- Amy, SunFounder Electronics

Code developed in Arduino 1.6.5.
****************************************************************/

#ifndef Rollman_h
#define Rollman_h

#include <Arduino.h>

// Pin aliases for the motor controller.
#define   MOTOR_R_DIR   4
#define   MOTOR_R_PWM   5
#define   MOTOR_L_PWM   6
#define   MOTOR_L_DIR   7

#define NOT_IN_USE    0
#define WHISKER       1
#define LENCODER      2
#define RENCODER      3

#define SW_SERIAL     4

#define PCINT_A0      0
#define PCINT_A1      1
#define PCINT_A2      2
#define PCINT_A3      3
#define PCINT_A4      4
#define PCINT_A5      5
#define PCINT_3       6
#define PCINT_9       7
#define PCINT_10      8
#define PCINT_11      9

#define LF 0
#define RT 1 

enum WHEEL {LEFT, RIGHT, BOTH};
void brake(void);//暂停

void setPinChangeInterrupt(int pin, byte role); //中断程序判断				  
void pinFunctionHandler(byte pinIndex);	//引脚定义
void PC0Handler(byte PBTemp);//PB引脚
void PC1Handler(byte PCTemp);//PC引脚
void PC2Handler(byte PDTemp);//PD引脚
		  
class RollmanMotors//电机驱动
{
  public:
    RollmanMotors();          			// Constructor. 主要用于引脚定义
	void stop();            			// Stop motors, but allow them to coast to a halt.
    void drive(int speed, int speed2); 	// drive(), but with a delay(duration)
 
 private:
    void setSpeeds( int speed_left,int speed_right); // These functions are pretty self-explanatory,
 };

// This handles the physical wire-whisker type bumper.
class RollmanBumper
{
  public:
    RollmanBumper(int pin); // Simple constructor; when the bumper gets hit, the
                           //  motors will stop.
    RollmanBumper(int pin, void(*functionPointer)(void)); // If the user wishes
                           //  to do something other than stop on a whisker,
                           //  bump, they can write a function to do so, and
                           //  use this constructor.
	boolean read();
  private:
    int _pin;
    void setBumpFunction(int pin, void(*functionPointer)(void));
};
// This is the reflectance sensor used for eg line following and table edge
//  detection. It's pretty crude, but since they're analog sensors, they're
//  kind of hard to work with.
class RollmanSensor//传感器
{
  public:
    RollmanSensor(int pin);  // Configure a pin as a sensor.
    int read();             // Return the current value of the pin.
    boolean check();        // In theory, this will be true if a deviation from
                            //  detectLevel is found; false otherwise.
    int setBGLevel();       // You can calibrate the sensor to detect a deviation
    int setDetectLevel();   //  from detectLevel; these functions allow for that.
    boolean calStatus();    // Have both calibrated levels been set yet?
  private:
    int _pin;
    int _BGLevel;
    int _detectLevel;
};

class RollmanEncoder//编码器
{
/*  // We declare a couple of friends, so they can have access to the private
  //  members of this class.
  friend class RollmanMotors;
  friend void pinFunctionHandler(byte pinIndex);
  public:
	RollmanEncoder(); 
	void EnCoderInit();
	void LwheelSpeed();
	void RwheelSpeed();
	int Lduration;
	int Rduration;
	*/
  friend class RollmanMotors;  // Needs access to lDir and rDir.
  friend void pinFunctionHandler(byte pinIndex); // Called from within the
                             //  ISRs, this function increments the counts
                             //  by calling wheelTick().
  public:
    RollmanEncoder(int lPin, int rPin); // Constructor. Assigns pins, pin
                             //  functions, zeroes counters, and adds a
                             //  reference to the new encoder object for other
                             //  library members to access.
    void clearEnc(WHEEL wheel); // Zaps the encoder count for a given wheel (or
                             //  for both wheels).
    long getTicks(WHEEL wheel); // Returns the encoder count for a wheel.
  private:
    void wheelTick(WHEEL wheel); // Increment or decrement a wheel's counts,
                             //  depending on which way the motor is turning.
    long lCounts;            // Holds the number of ticks for that wheel's
    long rCounts;            //  encoder.
    char lDir;               // Direction is set by the motor class, according
    char rDir;               //  to what the most recent motion direction for
                             //  the given wheel was.
							 
};

#define _SS_MAX_RX_BUFF 64 // RX buffer size
#ifndef GCC_VERSION
#define GCC_VERSION (__GNUC__ * 10000 + __GNUC_MINOR__ * 100 + __GNUC_PATCHLEVEL__)
#endif
class RollmanSoftwareSerial : public Stream
{
  friend void pinFunctionHandler(byte pinIndex);
  
  public:
    // public methods
    RollmanSoftwareSerial();
    ~RollmanSoftwareSerial();
    void begin(long speed);
    void end();
    bool overflow() { bool ret = _buffer_overflow; _buffer_overflow = false; return ret; }
    int peek();

    virtual size_t write(uint8_t byte);
    virtual int read();
    virtual int available();
    virtual void flush();
    
    using Print::write;
    
  private:
    // per object data
    uint8_t _receivePin;
    uint8_t _receiveBitMask;
    volatile uint8_t *_receivePortRegister;
    uint8_t _transmitBitMask;
    volatile uint8_t *_transmitPortRegister;

    uint16_t _rx_delay_centering;
    uint16_t _rx_delay_intrabit;
    uint16_t _rx_delay_stopbit;
    uint16_t _tx_delay;

    uint16_t _buffer_overflow:1;

    // static data
    static char _receive_buffer[_SS_MAX_RX_BUFF]; 
    static volatile uint8_t _receive_buffer_tail;
    static volatile uint8_t _receive_buffer_head;
    static RollmanSoftwareSerial *active_object;

    // private methods
    void recv();
    uint8_t rx_pin_read();
    void tx_pin_write(uint8_t pin_state);
    void setTX(uint8_t transmitPin);
    void setRX(uint8_t receivePin);

    // private static method for timing
    static inline void tunedDelay(uint16_t delay);

};
// We have a bunch of stuff associated with the accelerometer here. We're going
//  to implement our own I2C functions, too, to make things easy on ourselves.
#define XL_ADDR     0x1D // I2C address of the MMA8452Q accelerometer
#define I2C_READ    0x01 // I2C read bit set
// Some values we'll load into TWCR a lot
#define START_COND  0xA4 // (1<<TWINT) | (1<<TWSTA) | (1<<TWEN)
#define STOP_COND   0x94 // (1<<TWINT) | (1<<TWSTO) | (1<<TWEN)
#define CLEAR_TWINT 0x84 // (1<<TWINT) | (1<<TWEN)
#define NEXT_BYTE   0xC4 // (1<<TWINT) | (1<<TWEA) | (1<<TWEN)
class RollmanAccel//加速度
{
  public://全局
    RollmanAccel();     // Constructor...doesn't do much, since we re-configure
                       //  the TWI registers on each send/receive.
    void read();       // Puts the current readings of the accelerometer into
                       //  the x, y, and z variables to be checked by user.
    void enableBump(); // Put the accelerometer into a bump detection mode.
                       //  Useful for tap-input to the robot.
    boolean checkBump(); // Check to see if a tap has occurreed since the last
                       //  time this function was called.
    void setBumpThresh(int xThresh); // Adjust the threshold at which a bump
                       //  is detected. Too low and motion will set it off, too
                       //  high and it won't trigger when you want it to.
    int x;             // Rather than forcing users to grok pointers to read
    int y;             //  the three axes, we just populate this variables and
    int z;             //  let them be read as normal variables.
	float angleXZ;
	float angleXY;
	float angleYZ;
  
  private://局部
    void xlWriteBytes(byte addr, byte *buffer, byte len); // addr is the 
                       //  memory location on the device to be written to; buffer
                       //  and len are fairly self explanatory. Note that the
                       //  address in the device auto-increments after each
                       //  written, allowing consecutive registers to be written
                       //  with only one command.
    void xlReadBytes(byte addr, byte *buffer, byte len); // The same as the
                       //  write command, but with reading. Same rules apply.
};

class RollmanI2C //I2C
{
    public:
        RollmanI2C();
        
        static uint8_t i2cWrite(uint8_t registerAddress, uint8_t data, bool sendStop);    
		static uint8_t i2cWrites(uint8_t registerAddress, uint8_t *data, uint8_t length, bool sendStop);
		
		static uint8_t i2cRead(uint8_t registerAddress, uint8_t *data, uint8_t nbytes);
		
		static const uint8_t IMUAddress = 0x68; // AD0 is logic low on the PCB
		static const uint16_t I2C_TIMEOUT = 100; // Used to check for errors in I2C communication
};

class RollmanKalman//卡尔曼滤波
{
	public:
		RollmanKalman();
		float getAngle(float newAngle, float newRate, float dt);
	
		void setAngle(float angle);
		void setQangle(float Q_angle);
		void setQbias(float Q_bias);
		void setRmeasure(float R_measure);
	
		float getRate();
		float getQangle();
		float getQbias();
		float getRmeasure();
	private:
		float Q_angle; // Process noise variance for the accelerometer
		float Q_bias; // Process noise variance for the gyro bias
		float R_measure; // Measurement noise variance - this is actually the variance of the measurement noise

		float angle; // The angle calculated by the Kalman filter - part of the 2x1 state vector
		float bias; // The gyro bias calculated by the Kalman filter - part of the 2x1 state vector
		float rate; // Unbiased rate calculated from the rate and the calculated bias - you have to call getAngle to update the rate

		float P[2][2]; // Error covariance matrix - This is a 2x2 matrix
};
#endif
