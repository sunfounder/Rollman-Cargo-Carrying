/****************************************************************
Main CPP for Rollman motor control.

21 Dec 2015- Amy, SunFounder Electronics

Code developed in Arduino 1.6.5.
****************************************************************/

#include "Rollman.h"
#include <Arduino.h>

// Constructor. Mostly for pin setup; note that it's not necessary to configure
//  PWM pins as they will be automatically configured with the analogWrite()
//  function is called.

RollmanMotors::RollmanMotors()
{
  // The interface to the motor driver is kind of ugly. It's three pins per
  //  channel: two that define role (forward, reverse, stop, brake) and one
  //  PWM input for speed.
  pinMode(MOTOR_R_DIR, OUTPUT);
  pinMode(MOTOR_R_PWM, OUTPUT);
  pinMode(MOTOR_L_PWM, OUTPUT);
  pinMode(MOTOR_L_DIR, OUTPUT);
}


// stop() allows the motors to coast to a stop, rather than trying to stop them
//  quickly. As will be the case with functions affecting both motors, the
//  global stop just calls the individual stop functions for each wheel.
void RollmanMotors::stop()
{
  setSpeeds(0,0);
}


void RollmanMotors::drive(int speed1, int speed2)
{ // this variant of drive() integrates a delay duration to allow for single commmand instruction.
  setSpeeds(speed1,speed2);
}

// void RollmanMotors::drive(int speed1)
// { // this variant of drive() integrates a delay duration to allow for single commmand instruction.
  // setSpeeds(speed1);
// }

// void RollmanMotors::setSpeeds( int speed_left)//驱动
// {
	// if（speed_left）
    // if (speed_left>0)   
        // {
          // digitalWrite(MOTOR_L_DIR,HIGH);
          // analogWrite(MOTOR_L_PWM,speed_left);
        // }
    // else  
        // {
          // digitalWrite(MOTOR_L_DIR,LOW);
          // analogWrite(MOTOR_L_PWM,(-1)*speed_left);
        // }
// }
/******************************************************************************
Private functions for RollmanMotor-电机驱动-内部函数-只能底层调用
******************************************************************************/
void RollmanMotors::setSpeeds( int speed_left,int speed_right)//驱动
{
    if (speed_left>0)   
        {
          digitalWrite(MOTOR_L_DIR,HIGH);
          analogWrite(MOTOR_L_PWM,speed_left);
        }
    else  
        {
          digitalWrite(MOTOR_L_DIR,LOW);
          analogWrite(MOTOR_L_PWM,(-1)*speed_left);
        }
   if(speed_right>0)
        {
          digitalWrite(MOTOR_R_DIR,LOW);
          analogWrite(MOTOR_R_PWM,speed_right);
        }
   else   
        {
          digitalWrite(MOTOR_R_DIR,HIGH);
          analogWrite(MOTOR_R_PWM,(-1)*speed_right);
        }
}
