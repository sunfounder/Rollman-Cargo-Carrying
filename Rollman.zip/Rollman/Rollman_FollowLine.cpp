/****************************************************************
Main CPP for Rollman Follow Line.

21 Dec 2015- Amy, SunFounder Electronics

Code developed in Arduino 1.6.5.
****************************************************************/

#include "Rollman_FollowLine.h"
#include <Arduino.h>
#include <Wire.h>
/******************************************************************************
                巡线-内部函数-只能底层调用
******************************************************************************/
RollmanFollowLine::RollmanFollowLine()
{
  // The interface to the motor driver is kind of ugly. It's three pins per
  //  channel: two that define role (forward, reverse, stop, brake) and one
  //  PWM input for speed.
  pinMode(MOTOR_R_DIR, OUTPUT);
  pinMode(MOTOR_R_PWM, OUTPUT);
  pinMode(MOTOR_L_PWM, OUTPUT);
  pinMode(MOTOR_L_DIR, OUTPUT);
}
void RollmanFollowLine::Read_IICData()
{
  Wire.requestFrom(9, 16);    // request 16 bytes from slave device #9
  while(Wire.available())    // slave may send less than requested
  { 
    data[t] = Wire.read(); // receive a byte as character
    if(t<15) t++;
    else t=0;
  } 
}
void RollmanFollowLine::motordrives( int speed_left,int speed_right)//驱动
{
    if (speed_left>0)   
        {
          digitalWrite(MOTOR_L_DIR,HIGH);
          analogWrite(MOTOR_L_PWM,speed_left);
        }
    else  
        {
          digitalWrite(MOTOR_L_DIR,LOW);
          analogWrite(MOTOR_L_PWM,(-1)*speed_left);
        }
   if(speed_right>0)
        {
          digitalWrite(MOTOR_R_DIR,LOW);
          analogWrite(MOTOR_R_PWM,speed_right);
        }
   else   
        {
          digitalWrite(MOTOR_R_DIR,HIGH);
          analogWrite(MOTOR_R_PWM,(-1)*speed_right);
        }
}
void RollmanFollowLine::Threshold_Check(int ms)
{
  motordrives(-130,130);
  delay(ms);
  motordrives(0,0);
  Read_IICData();
  Min0=data[0];
  Max0=data[0];
  for(i=2;i<16;i=i+2)
  {
     if(data[i]<Min0)
         Min0=data[i];
     if(data[i]>Max0)
         Max0=data[i];
  }
  delay(ms);
  motordrives(130,-130);
  delay(ms);
  motordrives(0,0);
  Read_IICData();
  Min1=data[0];
  Max1=data[0];
  for(i=2;i<16;i=i+2)
  {
     if(data[i]<Min1)
         Min1=data[i];
     if(data[i]>Max1)
         Max1=data[i];
  }
  delay(ms);
  motordrives(130,-130);
  delay(ms);
  motordrives(0,0);
  Read_IICData();
  Min2=data[0];
  Max2=data[0];
  for(i=2;i<16;i=i+2)
  {
     if(data[i]<Min2)
         Min2=data[i];
     if(data[i]>Max2)
         Max2=data[i];
  }
  delay(ms);
  motordrives(-130,130);
  delay(ms);
  motordrives(0,0);
  threshold=((Min0+Min1+Min2)/3+(Max0+Max1+Max2)/3)/2;
}
unsigned char RollmanFollowLine::FollowLine_Position_Calculate()//计算位置
{    
  while(1)
  {
    Read_IICData();
    if (data[0] < threshold && data[2] > threshold && data[4] > threshold && data[6] > threshold && data[8] > threshold && data[10] > threshold && data[12] > threshold && data[14] > threshold) return 1;//10000000
    else if (data[0] < threshold && data[2] < threshold && data[4] > threshold && data[6] > threshold && data[8] > threshold && data[10] > threshold && data[12] > threshold && data[14] > threshold) return 2;//11000000
    else if (data[0] > threshold && data[2] < threshold && data[4] < threshold && data[6] > threshold && data[8] > threshold && data[10] > threshold && data[12] > threshold && data[14] > threshold) return 3;//01100000
    else if (data[0] > threshold && data[2] > threshold && data[4] < threshold && data[6] < threshold && data[8] > threshold && data[10] > threshold && data[12] > threshold && data[14] > threshold) return 4;//00110000 
    else if (data[0] > threshold && data[2] > threshold && data[4] > threshold && data[6] < threshold && data[8] < threshold && data[10] > threshold && data[12] > threshold && data[14] > threshold) return 5;//00011000 
    else if (data[0] > threshold && data[2] > threshold && data[4] > threshold && data[6] > threshold && data[8] < threshold && data[10] < threshold && data[12] > threshold && data[14] > threshold) return 6;//00001100
    else if (data[0] > threshold && data[2] > threshold && data[4] > threshold && data[6] > threshold && data[8] > threshold && data[10] < threshold && data[12] < threshold && data[14] > threshold) return 7;//00000110
    else if (data[0] > threshold && data[2] > threshold && data[4] > threshold && data[6] > threshold && data[8] > threshold && data[10] > threshold && data[12] < threshold && data[14] < threshold) return 8;//00000011
    else if (data[0] > threshold && data[2] > threshold && data[4] > threshold && data[6] > threshold && data[8] > threshold && data[10] > threshold && data[12] > threshold && data[14] < threshold) return 9;//00000001
  }
}
