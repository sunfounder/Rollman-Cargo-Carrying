/****************************************************************
Core header file for all the various Rollman functions.

21 Dec 2015- Amy, SunFounder Electronics

Code developed in Arduino 1.6.5.
****************************************************************/

#ifndef Rollman_Maze_h
#define Rollman_Maze_h

#include <Arduino.h>

#define   MOTOR_R_DIR   4
#define   MOTOR_R_PWM   5
#define   MOTOR_L_PWM   6
#define   MOTOR_L_DIR   7

class RollmanMaze//巡线
{
  public:
     RollmanMaze();
     unsigned char RollmanMaze_Position_Calculate(int ms);//计算位置  
     void Threshold_Check(int ms);
     void turn_left();
     void turn_right();
     void turn_back();
 private:
    int t=0;
    int threshold;
    unsigned int i;
    unsigned int Min0=0,Max0=0,Min1=0,Max1=0,Min2=0,Max2=0;
    unsigned char data[16];
    void Read_IICData();
    void motordrives(int speed_left,int speed_right);
 };


#endif

