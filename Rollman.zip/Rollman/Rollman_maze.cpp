/****************************************************************
Main CPP for Rollman Follow Line.

21 Dec 2015- Amy, SunFounder Electronics

Code developed in Arduino 1.6.5.
****************************************************************/

#include "Rollman_maze.h"
#include <Arduino.h>
#include <Wire.h>
/******************************************************************************
                巡线-内部函数-只能底层调用
******************************************************************************/
RollmanMaze::RollmanMaze()
{
  // The interface to the motor driver is kind of ugly. It's three pins per
  //  channel: two that define role (forward, reverse, stop, brake) and one
  //  PWM input for speed.
  pinMode(MOTOR_R_DIR, OUTPUT);
  pinMode(MOTOR_R_PWM, OUTPUT);
  pinMode(MOTOR_L_PWM, OUTPUT);
  pinMode(MOTOR_L_DIR, OUTPUT);
}
void RollmanMaze::Read_IICData()
{
  Wire.requestFrom(9, 16);    // request 16 bytes from slave device #9
  while(Wire.available())    // slave may send less than requested
  { 
    data[t] = Wire.read(); // receive a byte as character
    if(t<15) t++;
    else t=0;
  } 
}
void RollmanMaze::motordrives( int speed_left,int speed_right)//驱动
{
    if (speed_left>0)   
        {
          digitalWrite(MOTOR_L_DIR,HIGH);
          analogWrite(MOTOR_L_PWM,speed_left);
        }
    else  
        {
          digitalWrite(MOTOR_L_DIR,LOW);
          analogWrite(MOTOR_L_PWM,(-1)*speed_left);
        }
   if(speed_right>0)
        {
          digitalWrite(MOTOR_R_DIR,LOW);
          analogWrite(MOTOR_R_PWM,speed_right);
        }
   else   
        {
          digitalWrite(MOTOR_R_DIR,HIGH);
          analogWrite(MOTOR_R_PWM,(-1)*speed_right);
        }
}
unsigned char RollmanMaze::RollmanMaze_Position_Calculate(int ms)//计算位置
{    
  while(1)
  {
    Read_IICData();
    if (data[2] < threshold && data[4] < threshold && data[6] < threshold && data[8] < threshold && data[10] < threshold && data[12] < threshold) //x111111x
    {
       delay(ms); 
       Read_IICData();
       if (data[0] < threshold && data[2] < threshold && data[4] < threshold && data[6] < threshold && data[8] < threshold && data[10] < threshold && data[12] < threshold && data[14] < threshold) return 18;//11111111
       else if (data[2] < threshold || data[4] < threshold || data[6] < threshold || data[8] < threshold || data[10] < threshold || data[12] < threshold) return 17;//0xx11xx0
       else if (data[2] > threshold && data[4] > threshold && data[6] > threshold && data[8] > threshold && data[10] > threshold && data[12] > threshold) return 17;//00000000        
    }
    else if (data[0] < threshold && data[2] > threshold && data[4] > threshold && data[6] > threshold && data[8] > threshold && data[10] > threshold && data[12] > threshold && data[14] > threshold) return 1;//10000000  
    else if (data[0] < threshold && data[2] < threshold && data[4] > threshold && data[6] > threshold && data[8] > threshold && data[10] > threshold && data[12] > threshold && data[14] > threshold) return 2;//11000000
    else if (data[0] > threshold && data[2] < threshold && data[4] < threshold && data[6] > threshold && data[8] > threshold && data[10] > threshold && data[12] > threshold && data[14] > threshold) return 3;//01100000
    else if (data[0] > threshold && data[2] < threshold && data[4] < threshold && data[6] < threshold && data[8] > threshold && data[10] > threshold && data[12] > threshold && data[14] > threshold) return 4;//01110000
    else if (data[0] > threshold && data[2] > threshold && data[4] < threshold && data[6] < threshold && data[8] > threshold && data[10] > threshold && data[12] > threshold && data[14] > threshold) return 5;//00110000 
    else if (data[0] > threshold && data[2] > threshold && data[4] < threshold && data[6] < threshold && data[8] < threshold && data[10] > threshold && data[12] > threshold && data[14] > threshold) return 6;//00111000
    else if (data[0] > threshold && data[2] > threshold && data[4] > threshold && data[6] < threshold && data[8] < threshold && data[10] > threshold && data[12] > threshold && data[14] > threshold) return 7;//00011000
    else if (data[0] > threshold && data[2] > threshold && data[4] > threshold && data[6] < threshold && data[8] < threshold && data[10] < threshold && data[12] > threshold && data[14] > threshold) return 8;//00011100
    else if (data[0] > threshold && data[2] > threshold && data[4] > threshold && data[6] > threshold && data[8] < threshold && data[10] < threshold && data[12] > threshold && data[14] > threshold) return 9;//00001100
    else if (data[0] > threshold && data[2] > threshold && data[4] > threshold && data[6] > threshold && data[8] < threshold && data[10] < threshold && data[12] < threshold && data[14] > threshold) return 10;//00001110
    else if (data[0] > threshold && data[2] > threshold && data[4] > threshold && data[6] > threshold && data[8] > threshold && data[10] < threshold && data[12] < threshold && data[14] > threshold) return 11;//00000110
    else if (data[0] > threshold && data[2] > threshold && data[4] > threshold && data[6] > threshold && data[8] > threshold && data[10] > threshold && data[12] < threshold && data[14] < threshold) return 12;//00000011
    else if (data[0] > threshold && data[2] > threshold && data[4] > threshold && data[6] > threshold && data[8] > threshold && data[10] > threshold && data[12] > threshold && data[14] < threshold) return 13;//00000001         
    else if (data[0] < threshold && data[2] < threshold && data[4] < threshold && data[6] < threshold && data[12] > threshold && data[14] > threshold) return 14;//1111xx00         
    else if (data[0] < threshold && data[2] < threshold && data[4] < threshold && data[6] > threshold && data[8] > threshold && data[10] > threshold && data[12] > threshold && data[14] > threshold) //11100000cross         
    {
       delay(ms);
       Read_IICData();
       if (data[2] > threshold && data[4] > threshold && data[6] > threshold && data[8] > threshold && data[10] > threshold && data[12] > threshold) return 14;//00000000      
    }
    else if (data[0] < threshold && data[2] < threshold && data[4] < threshold && data[6] < threshold && data[8] < threshold && data[10] > threshold && data[12] > threshold && data[14] > threshold) //11100000cross         
    {
       delay(ms);
       Read_IICData();
       if (data[2] > threshold && data[4] > threshold && data[6] > threshold && data[8] > threshold && data[10] > threshold && data[12] > threshold) return 14;//00000000      
    }
    else if (data[0] > threshold && data[2] > threshold && data[4] > threshold && data[8] < threshold && data[10] < threshold && data[12] < threshold && data[14] < threshold) return 15;//00xx1111                     
    else if (data[0] > threshold && data[2] > threshold && data[4] > threshold && data[6] > threshold && data[8] > threshold && data[10] < threshold && data[12] < threshold && data[14] < threshold) //00000111cross    
    {
       delay(ms);
       Read_IICData();
       if (data[2] > threshold && data[4] > threshold && data[6] > threshold && data[8] > threshold && data[10] > threshold && data[12] > threshold) return 15;//00000000      
    }
    else if (data[0] > threshold && data[2] > threshold && data[4] > threshold && data[6] < threshold && data[8] < threshold && data[10] < threshold && data[12] < threshold && data[14] < threshold) //00000111cross    
    {
       delay(ms);
       Read_IICData();
       if (data[2] > threshold && data[4] > threshold && data[6] > threshold && data[8] > threshold && data[10] > threshold && data[12] > threshold) return 15;//00000000      
    }      
    else if (data[0] > threshold && data[2] > threshold && data[4] > threshold && data[6] > threshold && data[8] > threshold && data[10] > threshold && data[12] > threshold && data[14] > threshold) return 16;//00000000         
  }
}
void RollmanMaze::Threshold_Check(int ms)
{
  motordrives(-130,130);
  delay(ms);
  motordrives(0,0);
  Read_IICData();
  Min0=data[0];
  Max0=data[0];
  for(i=2;i<16;i=i+2)
  {
     if(data[i]<Min0)
         Min0=data[i];
     if(data[i]>Max0)
         Max0=data[i];
  }
  delay(ms);
  motordrives(130,-130);
  delay(ms);
  motordrives(0,0);
  Read_IICData();
  Min1=data[0];
  Max1=data[0];
  for(i=2;i<16;i=i+2)
  {
     if(data[i]<Min1)
         Min1=data[i];
     if(data[i]>Max1)
         Max1=data[i];
  }
  delay(ms);
  motordrives(130,-130);
  delay(ms);
  motordrives(0,0);
  Read_IICData();
  Min2=data[0];
  Max2=data[0];
  for(i=2;i<16;i=i+2)
  {
     if(data[i]<Min2)
         Min2=data[i];
     if(data[i]>Max2)
         Max2=data[i];
  }
  delay(ms);
  motordrives(-130,130);
  delay(ms);
  motordrives(0,0);
  threshold=((Min0+Min1+Min2)/3+(Max0+Max1+Max2)/3)/2;
}
void RollmanMaze::turn_left()
{
    motordrives(-120,120);   
    while (!(data[0]<threshold))  // tune - wait for line position to find near cente  
    {Read_IICData();}
    motordrives(-100,100);
    while (!(data[4]<threshold))  // tune - wait for line position to find near center
    {Read_IICData();}
    motordrives(0,0);
}
void RollmanMaze::turn_right()
{
    motordrives(120,-120); 
    while (!(data[14]<threshold))  // the right sensor;  
    {Read_IICData();}
    motordrives(100,-100);   
    while (!( data[10]<threshold))  // turn right - wait for line position to find near center
    {Read_IICData();}         
    motordrives(0,0);
}
void RollmanMaze::turn_back()
{
    motordrives(110,-110);   //right
    while (!(data[14]<threshold))  // the first sensor ; 
    {Read_IICData();}
    motordrives(90,-90); //turn left slowly
    while (!(data[10]<threshold ))  // tune - wait for line position to find near center
    {Read_IICData();}
    motordrives(0,0);
}



