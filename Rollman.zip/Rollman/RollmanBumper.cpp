/****************************************************************
Main CPP for Rollman whisker bumper.

21 Dec 2015- Amy, SunFounder Electronics

Code developed in Arduino 1.6.5.
****************************************************************/

#include "Rollman.h"
#include <Arduino.h>

void (*whiskerAction[10])(void); // Pointer to an array of functions
                                 //  describing what should happen if a
                                 //  given pin has a whisker event.
                                 
// Standard class constructor, assumes that you want to halt the motors on a
//  bump. A more skilled programmer than I could figure out the error message
//  I get if I try to use the brake() function that's a part of the RollmanMotor
//  class; I worked around it by making a globally available one.
RollmanBumper::RollmanBumper(int pin)
{
//  setPinChangeInterrupt(pin, WHISKER);
  pinMode(pin, INPUT_PULLUP);
  //setBumpFunction(pin, &brake);
  _pin = pin;  
}

// Bonus points constructor, which allows the user to connect a custom function to a bumper.
RollmanBumper::RollmanBumper(int pin, void(*functionPointer)(void))
{
  setPinChangeInterrupt(pin, WHISKER);
  pinMode(pin, INPUT_PULLUP);
  setBumpFunction(pin, functionPointer);
  _pin = pin; 
}

boolean RollmanBumper::read()
{
  return(digitalRead(_pin));
}

// I elected to create a function just to do this, rather than trying to wrap
//  it into the setPinChangeInterrupt() function. When a bumper action occurs,
//  a function will be called. By default, it's to brake the motors; users can
//  write a function of their own and this function will point the interrupt
//  at that custom function instead.
void RollmanBumper::setBumpFunction(int pin, void(*functionPointer)(void))
{
  switch(pin)
  {
    case A0:
      whiskerAction[PCINT_A0] = functionPointer;
      break;
    case A1:
      whiskerAction[PCINT_A1] = functionPointer;
      break;
    case A2:
      whiskerAction[PCINT_A2] = functionPointer;
      break;
    case A3:
      whiskerAction[PCINT_A3] = functionPointer;
      break;
    case A4:
      whiskerAction[PCINT_A4] = functionPointer;
      break;
    case A5:   
      whiskerAction[PCINT_A5] = functionPointer; 
      break;
    case 3:     
      whiskerAction[PCINT_3] = functionPointer;
      break;    
    case 9:     
      whiskerAction[PCINT_9] = functionPointer;
      break; 
    case 10: 
      whiskerAction[PCINT_10] = functionPointer;
      break; 
    case 11:
      whiskerAction[PCINT_11] = functionPointer;
      break;
  }
}