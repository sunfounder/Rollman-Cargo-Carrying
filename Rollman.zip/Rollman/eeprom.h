#ifndef __EEPROM_H__
#define __EEPROM_H__

#include <avr/io.h>

extern unsigned char EEPROM_Read(unsigned int uiAddress);
extern void EEPROM_Write(unsigned int uiAddress, unsigned char ucData);

#endif