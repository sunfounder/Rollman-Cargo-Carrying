/****************************************************************
Core header file for all the various Rollman functions.

21 Dec 2015- Amy, SunFounder Electronics

Code developed in Arduino 1.6.5.
****************************************************************/

#ifndef Rollman_FollowLine_h
#define Rollman_FollowLine_h

#include <Arduino.h>

#define   MOTOR_R_DIR   4
#define   MOTOR_R_PWM   5
#define   MOTOR_L_PWM   6
#define   MOTOR_L_DIR   7

class RollmanFollowLine//巡线
{
  public:
     RollmanFollowLine();
     unsigned char FollowLine_Position_Calculate();//计算位置  
     void Threshold_Check(int ms);
	 void motordrives(int speed_left,int speed_right);
	 void Read_IICData();
	 int t=0;
     int threshold;
     unsigned int i;
     unsigned int Min0=0,Max0=0,Min1=0,Max1=0,Min2=0,Max2=0;
     unsigned char data[16];  
    
 };


#endif
