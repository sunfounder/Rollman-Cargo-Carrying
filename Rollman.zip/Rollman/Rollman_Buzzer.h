/****************************************************************
Core header file for all the various Rollman functions.

21 Dec 2015- Amy, SunFounder Electronics

Code developed in Arduino 1.6.5.
****************************************************************/

#ifndef Rollman_Buzzer_h
#define Rollman_Buzzer_h

#include <Arduino.h>

#define NOTE_CL1 131
#define NOTE_CL2 147
#define NOTE_CL3 165
#define NOTE_CL4 175
#define NOTE_CL5 196
#define NOTE_CL6 221
#define NOTE_CL7 248

#define NOTE_C0 -1
#define NOTE_C1 262
#define NOTE_C2 294
#define NOTE_C3 330
#define NOTE_C4 350
#define NOTE_C5 393
#define NOTE_C6 441
#define NOTE_C7 495

#define NOTE_CH1 525
#define NOTE_CH2 589
#define NOTE_CH3 661
#define NOTE_CH4 700
#define NOTE_CH5 786
#define NOTE_CH6 882
#define NOTE_CH7 990

#define NOTE_DL1 147
#define NOTE_DL2 165
#define NOTE_DL3 175
#define NOTE_DL4 196
#define NOTE_DL5 221
#define NOTE_DL6 248
#define NOTE_DL7 278

#define NOTE_D0 -1
#define NOTE_D1 294
#define NOTE_D2 330
#define NOTE_D3 350
#define NOTE_D4 393
#define NOTE_D5 441
#define NOTE_D6 495
#define NOTE_D7 556
 
#define NOTE_DH1 589
#define NOTE_DH2 661
#define NOTE_DH3 700
#define NOTE_DH4 786
#define NOTE_DH5 882
#define NOTE_DH6 990
#define NOTE_DH7 1112

#define NOTE_EL7 312
#define NOTE_EL1 165
#define NOTE_EL2 175
#define NOTE_EL3 196
#define NOTE_EL4 221
#define NOTE_EL5 248
#define NOTE_EL6 278

#define NOTE_E0 -1
#define NOTE_E1 330
#define NOTE_E7 624 
#define NOTE_E2 350
#define NOTE_E3 393
#define NOTE_E4 441
#define NOTE_E5 495
#define NOTE_E6 556
 
#define NOTE_EH7 1248
#define NOTE_EH1 661
#define NOTE_EH2 700
#define NOTE_EH3 786
#define NOTE_EH4 882
#define NOTE_EH5 990
#define NOTE_EH6 1112

#define NOTE_G0 -1
#define NOTE_GL1 196
#define NOTE_GL2 221
#define NOTE_GL3 234
#define NOTE_GL4 262
#define NOTE_GL5 294
#define NOTE_GL6 330
#define NOTE_GL7 371
 
#define NOTE_G1 393
#define NOTE_G2 441
#define NOTE_G3 495
#define NOTE_G4 556
#define NOTE_G5 624
#define NOTE_G6 661
#define NOTE_G7 742
 
#define NOTE_GH1 700
#define NOTE_GH2 786
#define NOTE_GH3 882
#define NOTE_GH4 935
#define NOTE_GH5 1049
#define NOTE_GH6 1178
#define NOTE_GH7 1322

class RollmanBuzzer//巡线
{
  public:
    RollmanBuzzer(int pin);
    void Buzzer(int *tune,float *duration,int length);
 private:
    int tonePin;//蜂鸣器的pin
};

#endif
