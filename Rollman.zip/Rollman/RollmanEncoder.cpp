/****************************************************************
Main CPP for Rollman wheel encoder.

21 Dec 2015- Amy, SunFounder Electronics

Code developed in Arduino 1.6.5.
****************************************************************/

#include "Rollman.h"
#include <Arduino.h>


/*RollmanEncoder::RollmanEncoder()
{
  pinMode(encoder0pinA, INPUT);
  pinMode(encoder0pinB, INPUT);
  pinMode(encoder1pinA, INPUT);
  pinMode(encoder1pinB, INPUT);
  int Lduration;
  int Rduration;
}
void (*p)LwheelSpeed()
{
	if(digitalRead(encoder0pinB))
		Lduration++;
	else Lduration--;
}

void (*p)RwheelSpeed()
{
	if(digitalRead(encoder1pinB))
		Rduration--;
	else Rduration++;
}
void RollmanEncoder::EnCoderInit()
{
  attachInterrupt(LF, (*p)LwheelSpeed, RISING);
  attachInterrupt(RT, (*p)RwheelSpeed, RISING);
}
*/
RollmanEncoder *encoderObject=0; // Create a local pointer to an instance of this class-创建一个指针
                               

RollmanEncoder::RollmanEncoder(int lPin, int rPin)
{
  // We'll need a whopping case statement to set up the pin change interrupts
  //  for this; in fact, we'll need two, but I'll abstract it to a function.
  //  A call to setPinChangeInterrupt() enables pin change interrupts for that
  //  pin, and pin change interrupts for the group that pin is a part of.
  pinMode(lPin, INPUT_PULLUP);
  pinMode(rPin, INPUT_PULLUP);
  setPinChangeInterrupt(lPin, LENCODER);
  setPinChangeInterrupt(rPin, RENCODER);
  lCounts = 0;
  rCounts = 0;
  encoderObject = this; // We want a local pointer to the class member that is
                        //  instantiated in the sketch, so we can manipulate its
                        //  private members with other classes.
  lDir = 1;		// default direction to forward -- used for encoder counting默认向前，编码器计数
  rDir = 1;		// default direction to forward -- used for encoder counting默认向前，编码器计数
}

// This private function changes the counter when a tick happens. 编码器计数
void RollmanEncoder::wheelTick(WHEEL wheel)
{
  switch(wheel)
  {
    case LEFT:
      lCounts+= (long)lDir;
      break;
    case RIGHT:
      rCounts+= (long)rDir;
      break;
    case BOTH:
      break;
  }
}

// Public function to clear the encoder counts.编码器清零
void RollmanEncoder::clearEnc(WHEEL wheel)
{
  switch(wheel)
  {
    case LEFT:
      lCounts = 0;
      break;
    case RIGHT:
      rCounts = 0;
      break;
    case BOTH:
      lCounts = 0;
      rCounts = 0;
      break;
  }
}

// Public function to read the encoder counts for a given wheel.读取编码器的计数
long RollmanEncoder::getTicks(WHEEL wheel)
{
  switch(wheel)
  {
    case LEFT:
      return lCounts;
    case RIGHT:
      return rCounts;
    case BOTH:
      return 0;
  }
  return 0;
}