/****************************************************************
Core header file for all the various Rollman functions.

21 Dec 2015- Amy, SunFounder Electronics

Code developed in Arduino 1.6.5.
****************************************************************/
#ifndef Motors_h
#define Motors_h
#define Rollman_h

#include <Arduino.h>

// Pin aliases for the motor controller.
#define   MOTOR_R_DIR   4
#define   MOTOR_R_PWM   5
#define   MOTOR_L_PWM   6
#define   MOTOR_L_DIR   7

		  
class Motors//电机驱动
{
  public:
    Motors(int Motorpin);          			// Constructor. 主要用于引脚定义
	void stop();            			// Stop motors, but allow them to coast to a halt.
    void drive(int speed); 	// drive(), but with a delay(duration)
 
 private:
    void setSpeeds(int speed); // These functions are pretty self-explanatory,
 };

