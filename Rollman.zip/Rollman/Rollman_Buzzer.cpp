/****************************************************************
Main CPP for Rollman Follow Line.

21 Dec 2015- Amy, SunFounder Electronics

Code developed in Arduino 1.6.5.
****************************************************************/

#include "Rollman_Buzzer.h"

/******************************************************************************
                音乐-内部函数-只能底层调用
******************************************************************************/

RollmanBuzzer::RollmanBuzzer(int pin)
{
    pinMode(pin,OUTPUT);//设置蜂鸣器的pin为输出模式  
    tonePin=pin;
}
void RollmanBuzzer::Buzzer(int *tune,float *duration,int length)
{
    for(int x=0;x<length;x++)//循环音符的次数
    {
      tone(tonePin,tune[x]);//此函数依次播放tune序列里的数组，即每个音符
      delay(400*duration[x]);//每个音符持续的时间，即节拍duration，400是调整时间的越大，曲子速度越慢，越小曲子速度越快，自己掌握吧
      noTone(tonePin);//停止当前音符，进入下一音符
    }
}
