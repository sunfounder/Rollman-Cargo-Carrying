#include "eeprom.h"

void EEPROM_Write(unsigned int uiAddress, unsigned char ucData)
{
    // wait for completion of previous write
    while(EECR & (1 << EEPE))
        ;
    // set up address and Data Registers
    EEAR = uiAddress;
    EEDR = ucData;
    // write logical one to EEMPE
    EECR |= (1 << EEMPE);
    // Start eeprom write by setting EEPE
    EECR |= (1 << EEPE);
}

unsigned char EEPROM_Read(unsigned int uiAddress)
{
    // wait for completion of previous write
    while(EECR & (1 << EEPE))
        ;
    // Set up address register
    EEAR = uiAddress;
    // Start eeprom read by writing EERE
    EECR |= (1 << EERE);
    // Return data from data register
    return EEDR;
}